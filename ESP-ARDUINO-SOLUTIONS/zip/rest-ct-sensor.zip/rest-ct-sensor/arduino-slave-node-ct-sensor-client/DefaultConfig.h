/*
   Adarsh Model Trains
   Developed by Adarsh kumar
   Support adarshmodeltrains@gmail.com
*/

#ifndef DefaultConfig_h
#define DefaultConfig_h
#include "Arduino.h"
/************************************************************************************************/
#define ACTIVE ":AC\n"
#define INACTIVE ":IN\n"
#define BROAD_RATE 115200
#define DELAY_TIME 5000

#define INVALID_SENSOR_NUMBER " INVLAID SENEOR NUMBER "
/************************************************************************************************/
#endif
