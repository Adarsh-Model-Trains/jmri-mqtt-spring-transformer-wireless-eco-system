
/*
   Adarsh Model Trains
   Developed by Adarsh kumar
   Support adarshmodeltrains@gmail.com
*/

#ifndef Config_h
#define Config_h
#include "Arduino.h"

/************************************************************************************************/
#define BROAD_RATE 115200
#define DELAY_TIME 1000
#define WIFI_RECONNECT_DELAY_TIME 500
/************************************************************************************************/

// WiFi
// Make sure to update this for your own WiFi network!
#define ssid "adarsh_radha_2G" // ESP8266 do not support 5G wifi connection
#define wifi_password "******"
#define mqtt_username "adarsh"
#define mqtt_password "password"

// MQTT
// find this ip using ipconfig or check in router
#define mqtt_server "192.168.0.188"

// change the node "number/name"  based on the node default is 1 in this
#define mqtt_topic "/amt/node/1/#"

// change the node "number/name"  based on the node
#define clientID "JMRI_SUBSCRIBER_NODE_ESP8266_1"

#endif
