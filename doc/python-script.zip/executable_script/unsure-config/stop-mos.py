import subprocess

subprocess.call('killall mosquitto',shell=True)

